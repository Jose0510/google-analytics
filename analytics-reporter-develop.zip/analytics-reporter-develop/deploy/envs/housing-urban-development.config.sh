# Department of Housing and Urban Development
# HUD Agency
export ANALYTICS_REPORT_IDS="395457289"
export AGENCY_NAME=housing-urban-development
export AWS_BUCKET_PATH=data/$AGENCY_NAME
