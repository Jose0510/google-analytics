# Defense Nuclear Facilities Safety Board
# DNFSB Agency
export ANALYTICS_REPORT_IDS="395236998"
export AGENCY_NAME=defense-nuclear-facilities-safety-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
