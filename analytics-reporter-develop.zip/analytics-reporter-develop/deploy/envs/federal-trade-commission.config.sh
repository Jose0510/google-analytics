# Federal Trade Commission
# FTC Agency
export ANALYTICS_REPORT_IDS="395449415"
export AGENCY_NAME=federal-trade-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
