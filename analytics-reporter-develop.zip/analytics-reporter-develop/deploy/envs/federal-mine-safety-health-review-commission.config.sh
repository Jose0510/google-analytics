# Federal Mine Safety and Health Review Commission
# FMSHRC Agency
export ANALYTICS_REPORT_IDS="446076957"
export AGENCY_NAME=federal-mine-safety-health-review-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
