# Surface Transportation Board
# STB Agency
export ANALYTICS_REPORT_IDS="395461338"
export AGENCY_NAME=surface-transportation-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
