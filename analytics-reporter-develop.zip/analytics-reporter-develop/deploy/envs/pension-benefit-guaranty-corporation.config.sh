# Pension Benefit Guaranty Corporation
# PBGC Agency
export ANALYTICS_REPORT_IDS="395457296"
export AGENCY_NAME=pension-benefit-guaranty-corporation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
