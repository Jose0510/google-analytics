# Agency for International Development
# USAID Agency
export ANALYTICS_REPORT_IDS="395450427"
export AGENCY_NAME=agency-international-development
export AWS_BUCKET_PATH=data/$AGENCY_NAME
