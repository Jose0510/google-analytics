# National Aeronautics and Space Administration
# NASA Agency
export ANALYTICS_REPORT_IDS="395454267"
export AGENCY_NAME=national-aeronautics-space-administration
export AWS_BUCKET_PATH=data/$AGENCY_NAME
