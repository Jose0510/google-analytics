# Federal Retirement Thrift Investment Board
# FRTIB Agency
export ANALYTICS_REPORT_IDS="395449505"
export AGENCY_NAME=federal-retirement-thrift-investment-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
