# National Council on Disability
# NCD Agency
export ANALYTICS_REPORT_IDS="432696271"
export AGENCY_NAME=national-council-disability
export AWS_BUCKET_PATH=data/$AGENCY_NAME
