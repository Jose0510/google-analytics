# Postal Regulatory Commission
# PRC Agency
export ANALYTICS_REPORT_IDS="407064941"
export AGENCY_NAME=postal-regulatory-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
