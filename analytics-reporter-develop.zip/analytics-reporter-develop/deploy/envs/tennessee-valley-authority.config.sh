# Tennessee Valley Authority
# TVA Agency
export ANALYTICS_REPORT_IDS="449053587"
export AGENCY_NAME=tennessee-valley-authority
export AWS_BUCKET_PATH=data/$AGENCY_NAME
