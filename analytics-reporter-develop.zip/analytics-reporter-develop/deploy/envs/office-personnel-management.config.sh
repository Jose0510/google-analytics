# Office of Personnel Management
# OPM Agency
export ANALYTICS_REPORT_IDS="395441051"
export AGENCY_NAME=office-personnel-management
export AWS_BUCKET_PATH=data/$AGENCY_NAME
