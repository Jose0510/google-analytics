# Millennium Challenge Corporation
# MCC Agency
export ANALYTICS_REPORT_IDS="395454156"
export AGENCY_NAME=millennium-challenge-corporation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
