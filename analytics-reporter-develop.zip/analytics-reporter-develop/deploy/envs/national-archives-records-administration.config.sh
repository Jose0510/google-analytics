# National Archives and Records Administration
# NARA Agency
export ANALYTICS_REPORT_IDS="395458906"
export AGENCY_NAME=national-archives-records-administration
export AWS_BUCKET_PATH=data/$AGENCY_NAME
