# Peace Corps
# Peace Corps Agency
export ANALYTICS_REPORT_IDS="395459211"
export AGENCY_NAME=peace-corps
export AWS_BUCKET_PATH=data/$AGENCY_NAME
