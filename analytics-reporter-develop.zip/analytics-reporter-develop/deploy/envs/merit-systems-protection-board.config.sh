# Merit Systems Protection Board
# MSPB Agency
export ANALYTICS_REPORT_IDS="395444789"
export AGENCY_NAME=merit-systems-protection-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
