# National Transportation Safety Board
# NTSB Agency
export ANALYTICS_REPORT_IDS="395446803"
export AGENCY_NAME=national-transportation-safety-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
