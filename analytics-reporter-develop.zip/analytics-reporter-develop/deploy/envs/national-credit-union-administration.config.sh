# National Credit Union Administration
# NCUA Agency
export ANALYTICS_REPORT_IDS="395453466"
export AGENCY_NAME=national-credit-union-administration
export AWS_BUCKET_PATH=data/$AGENCY_NAME
