# National Science Foundation
# NSF Agency
export ANALYTICS_REPORT_IDS="395443988"
export AGENCY_NAME=national-science-foundation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
