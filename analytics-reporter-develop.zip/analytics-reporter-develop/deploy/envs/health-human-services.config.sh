# Department of Health and Human Services
# HHS Agency
export ANALYTICS_REPORT_IDS="395460726"
export AGENCY_NAME=health-human-services
export AWS_BUCKET_PATH=data/$AGENCY_NAME

