# International Development Finance Corporation
# DFC Agency
export ANALYTICS_REPORT_IDS="395113416"
export AGENCY_NAME=international-development-finance-corporation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
