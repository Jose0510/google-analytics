# Office of Navajo and Hopi Indian Relocation
# ONHIR Agency
export ANALYTICS_REPORT_IDS="426919252"
export AGENCY_NAME=office-navajo-hopi-indian-relocation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
