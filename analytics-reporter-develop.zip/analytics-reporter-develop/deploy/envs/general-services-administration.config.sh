# General Services Administration
# GSA Agency
export ANALYTICS_REPORT_IDS="395251184"
export AGENCY_NAME=general-services-administration
export AWS_BUCKET_PATH=data/$AGENCY_NAME
