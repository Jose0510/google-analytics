# Department of Transportation
# DOT Agency
export ANALYTICS_REPORT_IDS="395245646"
export AGENCY_NAME=transportation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
