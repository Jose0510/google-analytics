# Equal Employment Opportunity Commission
# EEOC Agency
export ANALYTICS_REPORT_IDS="395227834"
export AGENCY_NAME=equal-employment-opportunity-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
