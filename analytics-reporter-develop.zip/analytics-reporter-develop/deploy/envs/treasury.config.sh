# Department of the Treasury
# Dept of Treasury Agency
export ANALYTICS_REPORT_IDS="395126080"
export AGENCY_NAME=treasury
export AWS_BUCKET_PATH=data/$AGENCY_NAME
