# Department of Defense
# DOD Agency
export ANALYTICS_REPORT_IDS="395251747"
export AGENCY_NAME=defense
export AWS_BUCKET_PATH=data/$AGENCY_NAME
