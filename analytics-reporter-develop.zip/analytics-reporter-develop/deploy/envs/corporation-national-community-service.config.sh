# Corporation for National and Community Service
# CNCS Agency
export ANALYTICS_REPORT_IDS="395233541"
export AGENCY_NAME=corporation-national-community-service
export AWS_BUCKET_PATH=data/$AGENCY_NAME
