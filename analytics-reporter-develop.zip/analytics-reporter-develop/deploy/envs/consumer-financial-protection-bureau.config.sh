# Consumer Financial Protection Bureau
# CFPB Agency
export ANALYTICS_REPORT_IDS="395252447"
export AGENCY_NAME=consumer-financial-protection-bureau
export AWS_BUCKET_PATH=data/$AGENCY_NAME
