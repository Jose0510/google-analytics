# Federal Maritime Commission
# FMC Agency
export ANALYTICS_REPORT_IDS="445602092"
export AGENCY_NAME=federal-maritime-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
