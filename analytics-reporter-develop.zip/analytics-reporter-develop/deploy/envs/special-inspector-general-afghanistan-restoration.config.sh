# Special Inpector General for Afghanistan Restoration
# SIGAR Agency
export ANALYTICS_REPORT_IDS="395438870"
export AGENCY_NAME=special-inspector-general-afghanistan-restoration
export AWS_BUCKET_PATH=data/$AGENCY_NAME
