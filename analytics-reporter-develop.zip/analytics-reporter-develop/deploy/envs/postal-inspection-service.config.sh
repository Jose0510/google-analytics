# U.S. Postal Inspection Service
# USPIS Agency
export ANALYTICS_REPORT_IDS="422356675"
export AGENCY_NAME=postal-inspection-service
export AWS_BUCKET_PATH=data/$AGENCY_NAME
