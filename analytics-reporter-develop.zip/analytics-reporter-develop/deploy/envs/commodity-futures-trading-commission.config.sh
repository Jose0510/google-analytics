# Commodity Futures Trading Commission
# CFTC Agency
export ANALYTICS_REPORT_IDS="395256592"
export AGENCY_NAME=commodity-futures-trading-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
