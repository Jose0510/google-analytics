# Environmental Protection Agency
# EPA Agency
export ANALYTICS_REPORT_IDS="395252829"
export AGENCY_NAME=environmental-protection-agency
export AWS_BUCKET_PATH=data/$AGENCY_NAME

