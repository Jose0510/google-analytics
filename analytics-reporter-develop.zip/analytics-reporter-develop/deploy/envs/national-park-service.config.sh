# National Park Service
# NPS Agency
export ANALYTICS_REPORT_IDS="395455884"
export AGENCY_NAME=national-park-service
export AWS_BUCKET_PATH=data/$AGENCY_NAME
