# Public Buildings Reform Board
# PBRB Agency
export ANALYTICS_REPORT_IDS="397625389"
export AGENCY_NAME=public-buildings-reform-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
