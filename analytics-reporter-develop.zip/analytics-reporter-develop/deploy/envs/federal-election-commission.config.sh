# Federal Election Commission
# FEC Agency
export ANALYTICS_REPORT_IDS="395446398"
export AGENCY_NAME=federal-election-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
