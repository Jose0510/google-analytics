# Department of Veterans Affairs
# Veterans Affairs Agency
export ANALYTICS_REPORT_IDS="395452039"
export AGENCY_NAME=veterans-affairs
export AWS_BUCKET_PATH=data/$AGENCY_NAME
