# Consumer Product Safety Commission
# CPSC Agency
export ANALYTICS_REPORT_IDS="395229915"
export AGENCY_NAME=consumer-product-safety-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
