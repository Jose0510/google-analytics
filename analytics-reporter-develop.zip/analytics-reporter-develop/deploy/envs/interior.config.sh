# Department of the Interior
# DOI Agency
export ANALYTICS_REPORT_IDS="395227436"
export AGENCY_NAME=interior
export AWS_BUCKET_PATH=data/$AGENCY_NAME
