# Inter-American Foundation
# IAF Agency
export ANALYTICS_REPORT_IDS="424430051"
export AGENCY_NAME=inter-american-foundation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
