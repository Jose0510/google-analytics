# Department of Energy
# DOE Agency
export ANALYTICS_REPORT_IDS="395236978"
export AGENCY_NAME=energy
export AWS_BUCKET_PATH=data/$AGENCY_NAME

