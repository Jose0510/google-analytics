# Federal Housing Finance Agency
# FHFA Agency
export ANALYTICS_REPORT_IDS="395442267"
export AGENCY_NAME=federal-housing-finance-agency
export AWS_BUCKET_PATH=data/$AGENCY_NAME
