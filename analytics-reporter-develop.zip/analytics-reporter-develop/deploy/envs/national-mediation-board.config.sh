# National Mediation Board
# NMB Agency
export ANALYTICS_REPORT_IDS="425930242"
export AGENCY_NAME=national-mediation-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
