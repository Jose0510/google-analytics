# American Battle Monuments Commission
# ABMC Agency
export ANALYTICS_REPORT_IDS="395213963"
export AGENCY_NAME=american-battle-monuments-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
