# Department of Justice
# DOJ Agency
export ANALYTICS_REPORT_IDS="395234366"
export AGENCY_NAME=justice
export AWS_BUCKET_PATH=data/$AGENCY_NAME
