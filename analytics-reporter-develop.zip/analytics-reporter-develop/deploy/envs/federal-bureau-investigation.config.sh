# Federal Bureau of Investigation
# FBI Agency
export ANALYTICS_REPORT_IDS="395455171"
export AGENCY_NAME=federal-bureau-investigation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
