# Department of Education
# Dept of Education Agency
export ANALYTICS_REPORT_IDS="395246701"
export AGENCY_NAME=education
export AWS_BUCKET_PATH=data/$AGENCY_NAME
