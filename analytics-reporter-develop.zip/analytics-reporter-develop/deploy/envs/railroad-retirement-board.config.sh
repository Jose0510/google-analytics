# U.S. Railroad Retirement Board
# RRB Agency
export ANALYTICS_REPORT_IDS="395455287"
export AGENCY_NAME=railroad-retirement-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
