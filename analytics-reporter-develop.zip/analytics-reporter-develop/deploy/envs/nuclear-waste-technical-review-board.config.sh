# Nuclear Waste Technical Review Board
# NWTRB Agency
export ANALYTICS_REPORT_IDS="436324183"
export AGENCY_NAME=nuclear-waste-technical-review-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
