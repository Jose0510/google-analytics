# U.S. Access Board
# Access Board Agency
export ANALYTICS_REPORT_IDS="395456687"
export AGENCY_NAME=access-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
