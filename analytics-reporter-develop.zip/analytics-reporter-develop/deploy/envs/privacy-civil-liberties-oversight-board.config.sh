# Privacy and Civil Liberties Oversight Board
# PCLOB Agency
export ANALYTICS_REPORT_IDS="395461632"
export AGENCY_NAME=privacy-civil-liberties-oversight-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
