# Small Business Administration
# SBA Agency
export ANALYTICS_REPORT_IDS="395437327"
export AGENCY_NAME=small-business-administration
export AWS_BUCKET_PATH=data/$AGENCY_NAME
