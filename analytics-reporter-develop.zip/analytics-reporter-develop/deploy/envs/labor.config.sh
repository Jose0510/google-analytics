# Department of Labor
# DOL Agency
export ANALYTICS_REPORT_IDS="395262085"
export AGENCY_NAME=labor
export AWS_BUCKET_PATH=data/$AGENCY_NAME
