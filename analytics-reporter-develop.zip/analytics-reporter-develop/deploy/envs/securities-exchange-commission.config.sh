# Securities and Exchange Commission
# SEC Agency
export ANALYTICS_REPORT_IDS="395463162"
export AGENCY_NAME=securities-exchange-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
