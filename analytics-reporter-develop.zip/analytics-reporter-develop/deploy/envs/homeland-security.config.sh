# Department of Homeland Security
# DHS Agency
export ANALYTICS_REPORT_IDS="395243274"
export AGENCY_NAME=homeland-security
export AWS_BUCKET_PATH=data/$AGENCY_NAME

