# Office of Government Ethics
# OGE Agency
export ANALYTICS_REPORT_IDS="395449111"
export AGENCY_NAME=office-government-ethics
export AWS_BUCKET_PATH=data/$AGENCY_NAME
