# National Reconnaissance Office
# NMB Agency
export ANALYTICS_REPORT_IDS="426999924"
export AGENCY_NAME=national-reconnaissance-office
export AWS_BUCKET_PATH=data/$AGENCY_NAME
