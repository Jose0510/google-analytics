# U.S. International Trade Commission
# USITC Agency
export ANALYTICS_REPORT_IDS="395460932"
export AGENCY_NAME=international-trade-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
