# Nuclear Regulatory Commission
# NRC Agency
export ANALYTICS_REPORT_IDS="395460734"
export AGENCY_NAME=nuclear-regulatory-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
