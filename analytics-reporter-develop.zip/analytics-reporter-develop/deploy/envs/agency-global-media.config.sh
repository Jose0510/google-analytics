# U.S. Agency for Global Media
# USAGM Agency
export ANALYTICS_REPORT_IDS="395453549"
export AGENCY_NAME=agency-global-media
export AWS_BUCKET_PATH=data/$AGENCY_NAME
