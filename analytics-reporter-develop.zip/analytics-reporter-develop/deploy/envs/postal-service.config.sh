# Postal Service
# USPS Agency
export ANALYTICS_REPORT_IDS="395466379"
export AGENCY_NAME=postal-service
export AWS_BUCKET_PATH=data/$AGENCY_NAME
