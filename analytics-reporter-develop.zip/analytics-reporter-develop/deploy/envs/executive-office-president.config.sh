# Executive Office of the President
export ANALYTICS_REPORT_IDS="395437322"
export AGENCY_NAME=executive-office-president
export AWS_BUCKET_PATH=data/$AGENCY_NAME
