# Farm Credit Administration
# FCA Agency
export ANALYTICS_REPORT_IDS="433204342"
export AGENCY_NAME=farm-credit-administration
export AWS_BUCKET_PATH=data/$AGENCY_NAME
