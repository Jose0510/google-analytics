# National Endowment for the Humanities
# NEH Agency
export ANALYTICS_REPORT_IDS="395450224"
export AGENCY_NAME=national-endowment-humanities
export AWS_BUCKET_PATH=data/$AGENCY_NAME
