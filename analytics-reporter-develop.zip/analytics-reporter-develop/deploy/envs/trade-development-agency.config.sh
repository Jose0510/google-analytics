# U.S. Trade and Development Agency
# USTDA Agency
export ANALYTICS_REPORT_IDS="397513313"
export AGENCY_NAME=trade-development-agency
export AWS_BUCKET_PATH=data/$AGENCY_NAME
