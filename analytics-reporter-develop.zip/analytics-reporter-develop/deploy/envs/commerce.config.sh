# Department of Commerce
# DOC Agency
export ANALYTICS_REPORT_IDS="395253935"
export AGENCY_NAME=commerce
export AWS_BUCKET_PATH=data/$AGENCY_NAME
