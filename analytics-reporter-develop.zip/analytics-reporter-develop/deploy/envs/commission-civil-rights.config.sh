# U.S. Commission on Civil Rights
# USCCR Agency
export ANALYTICS_REPORT_IDS="395463975"
export AGENCY_NAME=commission-civil-rights
export AWS_BUCKET_PATH=data/$AGENCY_NAME
