# National Capital Planning Commission
# NCPC Agency
export ANALYTICS_REPORT_IDS="395459624"
export AGENCY_NAME=national-capital-planning-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
