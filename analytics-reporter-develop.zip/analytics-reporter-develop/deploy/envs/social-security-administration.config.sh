# Social Security Administration
# SSA Agency
export ANALYTICS_REPORT_IDS="397629136"
export AGENCY_NAME=social-security-administration
export AWS_BUCKET_PATH=data/$AGENCY_NAME
