# Office of the Director of National Intelligence
# ODNI Agency
export ANALYTICS_REPORT_IDS="395449711"
export AGENCY_NAME=office-director-national-intelligence
export AWS_BUCKET_PATH=data/$AGENCY_NAME
