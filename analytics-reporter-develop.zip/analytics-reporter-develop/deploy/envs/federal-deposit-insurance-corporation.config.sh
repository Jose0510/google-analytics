# Federal Deposit Insurance Corporation
# FDIC Agency
export ANALYTICS_REPORT_IDS="395455467"
export AGENCY_NAME=federal-deposit-insurance-corporation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
