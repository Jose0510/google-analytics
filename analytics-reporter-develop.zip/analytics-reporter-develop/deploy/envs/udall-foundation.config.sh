# Udall Foundation
# Udall Foundation Agency
export ANALYTICS_REPORT_IDS="431046847"
export AGENCY_NAME=udall-foundation
export AWS_BUCKET_PATH=data/$AGENCY_NAME
