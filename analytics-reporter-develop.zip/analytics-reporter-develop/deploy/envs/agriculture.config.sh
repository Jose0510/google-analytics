# Department of Agriculture
# USDA Agency
export ANALYTICS_REPORT_IDS="395461442"
export AGENCY_NAME=agriculture
export AWS_BUCKET_PATH=data/$AGENCY_NAME
