# Denali Commission
export ANALYTICS_REPORT_IDS="451719437"
export AGENCY_NAME=denali-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
