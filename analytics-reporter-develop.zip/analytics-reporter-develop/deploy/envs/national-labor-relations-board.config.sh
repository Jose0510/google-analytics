# National Labor Relations Board
# NLRB Agency
export ANALYTICS_REPORT_IDS="395452956"
export AGENCY_NAME=national-labor-relations-board
export AWS_BUCKET_PATH=data/$AGENCY_NAME
