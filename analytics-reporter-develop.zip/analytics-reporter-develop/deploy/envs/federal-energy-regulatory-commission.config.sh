# Federal Energy Regulatory Commission
# FERC Agency
export ANALYTICS_REPORT_IDS="395457791"
export AGENCY_NAME=federal-energy-regulatory-commission
export AWS_BUCKET_PATH=data/$AGENCY_NAME
