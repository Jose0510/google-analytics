/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function (knex) {
  return knex.schema.table("analytics_data_ga4", (table) => {
    table.dropColumn("version");
  });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function (knex) {
  return knex.schema.table("analytics_data_ga4", (table) => {
    table.string("version");
  });
};
